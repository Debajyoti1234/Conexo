  import 'package:flutter/material.dart' hide ConnectionState;

  import 'home_discovery_components.dart';
  import 'home_discovery_data.dart';

  class HomeScreen extends StatefulWidget {
    const HomeScreen({super.key});
    @override
    State<HomeScreen> createState() => _HomeScreenState();
  }

  class _HomeScreenState extends State<HomeScreen> {
    int _personIndex = 0;
    ConnectionState _state = ConnectionState.none;

    void _respond(bool interested) {
      setState(
        () => _state = interested
            ? ConnectionState.pending
            : ConnectionState.declined,
      );
    }

    @override
    Widget build(BuildContext context) {
      final person = peopleAroundYou[_personIndex];
      return SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 860),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 36),
              children: [
                const _Hero(),
                const SizedBox(height: 24),
                const PremiumSearchBar(),
                const SizedBox(height: 36),
                const DiscoverySectionHeader(
                  'People around you',
                  subtitle: 'Open to a genuine conversation nearby',
                ),
                const SizedBox(height: 14),
                Dismissible(
                  key: ValueKey(person.name),
                  direction: DismissDirection.horizontal,
                  onDismissed: (direction) =>
                      _respond(direction == DismissDirection.startToEnd),
                  child: PersonDiscoveryCard(
                    person: person,
                    state: _state,
                    onRequest: () => _respond(true),
                    onDecline: () => _respond(false),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: () => setState(() {
                      _personIndex = (_personIndex + 1) % peopleAroundYou.length;
                      _state = ConnectionState.none;
                    }),
                    child: const Text('Meet someone else'),
                  ),
                ),
                const SizedBox(height: 28),
                const DiscoverySectionHeader(
                  'Conversations starting',
                  subtitle: 'Small openings to meet people tonight',
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 132,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: conversations.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, index) =>
                        ConversationCard(conversation: conversations[index]),
                  ),
                ),
                const SizedBox(height: 34),
                const DiscoverySectionHeader(
                  'Your interest circles',
                  subtitle: 'Communities shaped around what you enjoy',
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 126,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: circles.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, index) => CircleCard(circle: circles[index]),
                  ),
                ),
                const SizedBox(height: 34),
                const DiscoverySectionHeader(
                  'Nearby moments',
                  subtitle: 'A little company can change the evening',
                ),
                const SizedBox(height: 14),
                for (final moment in nearbyMoments) ...[
                  NearbyMomentCard(moment: moment),
                  const SizedBox(height: 12),
                ],
              ],
            ),
          ),
        ),
      );
    }
  }

  class _Hero extends StatelessWidget {
    const _Hero();
    @override
    Widget build(BuildContext context) => Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Good Evening 👋',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: const Color(0xFFD6DCF0),
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "You don't have to spend tonight alone.",
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w800,
            letterSpacing: -.9,
            height: 1.16,
          ),
        ),
        const SizedBox(height: 12),
        const Row(
          children: [
            Icon(Icons.near_me_rounded, size: 16, color: Color(0xFF22D3EE)),
            SizedBox(width: 7),
            Text(
              '23 people nearby are open to connect',
              style: TextStyle(
                color: Color(0xFFB9C3DC),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ],
    );
  }
